var app = angular.module('virtualPantry', ['ui.router']);

app.controller('mainController', [
  '$scope',
  '$http',
  function($scope, $http){
    $scope.test='Our basic upvoting system';
    $http.get('api/posts')
      .success(function(data) {
        $scope.posts = data.posts;
        console.log(data);
      })
      .error(function(data) {
        console.log('Error: ' + data);
      });
    $scope.createPost = function() {
      if(!$scope.title || $scope.title === '') { return; }
      $http.post('/api/posts', {
            title: $scope.title,
            link: $scope.link})
        .success(function(data) {
          $scope.posts = data.posts;
          $scope.title = '';
          $scope.link = '';
          console.log(data);
        })
        .error(function(data) {
          console.log('Error: ' + data);
        });
    };
}]);
