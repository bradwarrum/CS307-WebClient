var express = require("express");
var app = express();

var morgan = require("morgan");
var bodyParser = require('body-parser');

app.use(express.static('./public'));
app.use(morgan('dev'));


//bodyParser is used for get and post requests
app.use(bodyParser.json())

//test variable for all the posts
var Post = {
  posts:  [
    {title: 'post 1', upvotes: 5},
    {title: 'post 2', upvotes: 2},
    {title: 'post 3', upvotes: 15},
    {title: 'post 4', upvotes: 9},
    {title: 'post 5', upvotes: 4}
  ]
};


//API routes for angluar to call
app.get('/api/posts', function(request, response) {
  response.json(Post);
});

app.post('/api/posts', function(request, response) {
  Post.posts.push({
    title: request.body.title,
    link: request.body.link,
    upvotes: '0'
  });
  console.log("adding post: " + request.body);
  response.json(Post);
});


//By default, sends you to index.html
app.get('*', function(req, res) {
        res.sendfile('./public/index.html'); // load the single view file (angular will handle the page changes on the front-end)
});
//start the server
app.listen(8081);
console.log("App listening on port 8081");
